class aspectNuts(models.Model):
    _name = 'aspect.nuts'

    name = fields.Char(string="Name", compute='_get_name')
    country = fields.Many2one('res.country', string="Country")
    country_code = fields.Char(string="Country Code")
    nuts_code = fields.Char(string="Code")
    nuts_label_eng = fields.Char(string="Label (English)")
    nuts_label = fields.Char(string="Label")
    nuts_level = fields.Selection([("1", "1"), ("2", "2"),("3", "3")], string="Level")
    polygon_file = fields.Binary('Shape File')
    country_map = fields.Boolean('For Country Map')
    state_map = fields.Boolean('For State Map')
    country_state = fields.Many2one('res.country.state', string="State", domain="[('country_id','=', country)]")
    geo_multipolygon = fields.GeoMultiPolygon(string="Shape Multi Poliygon")

    @api.onchange('country', 'nuts_level', 'state_map', 'country_map')
    def _get_name(self):
        for record in self:
            if record.state_map:
                record.name = str(record.country_state.name)
            elif record.country_map:
                record.name = str(record.country.name)
            else:
                record.name = str(record.country.name)+" - "+str(record.nuts_code)+ ' - Level:'+str(record.nuts_level)+ ' - Label:'+str(record.nuts_label)

    @api.model
    def _name_search(self, name='', args=None, operator='ilike', limit=100, name_get_uid=None):
        args = list(args or [])
        if name:
            args += ['|', '|', '|',('country', operator, name), ('nuts_code', operator, name), ('nuts_label_eng', operator, name), ('nuts_label', operator, name), ('country_state', operator, name)]
        return self._search(args, limit=limit, access_rights_uid=name_get_uid)
 